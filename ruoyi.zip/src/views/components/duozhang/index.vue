<template>
  <div>
    
  </div>
</template>

<script>
export default {
  components: {},
  props: {},
  data() {
    return {
      imageUrl: "",
      dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px'
    };
  },
  computed: {},
  methods: {
    
  },
  created() {},
  mounted() {},
};
</script>
<style scoped>
</style>