<template>
<div>
    遮罩层
</div>
</template>

<script>

export default {
components: {},
props: {},
data() {
return {

}
},
computed: {},
methods: {

},
created() {

},
mounted() {

},
}
</script>
<style scoped>

</style>